package dev.smartleave.smartleave;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SmartleaveApplicationTests {

	@Test
	void contextLoads() {
	}

}
