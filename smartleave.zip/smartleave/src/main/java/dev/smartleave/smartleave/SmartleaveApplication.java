package dev.smartleave.smartleave;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SmartleaveApplication {

	public static void main(String[] args) {
		SpringApplication.run(SmartleaveApplication.class, args);
	}

}
